/* Placeholder for book cover - Replace with actual book cover image */
/* Recommended dimensions: 400x600px minimum, high quality JPG or PNG */

/* This file serves as a placeholder. To add your actual book cover:
   1. Create an 'assets' folder in the project root
   2. Add your book cover image as 'book-cover.jpg'
   3. Ensure the image is optimized for web (under 500KB)
   4. Update the src attribute in index.html if needed
*/

/* Alternative approach: Use a CSS-generated placeholder until real image is available */
